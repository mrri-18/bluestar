#pragma once
#ifndef CAR_H
#define CAR_H

class Car {
private:
	int speed;
public:
	Car();
	void setSpeed(int speed);
	int getSpeed();
};
Car::Car() {speed = 10;}
void Car::setSpeed(int s) {
	if (s < 0) {
		speed = 0;
	}
	else {
		speed = s;
	}
}
int Car::getSpeed() {
	return speed;
}
#endif


